package com.cg.billing.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billing.beans.Customer;
import com.cg.billing.beans.PostpaidAccount;

public class PostpaidAccountDAOImpl implements PostpaidAccountDAO{

	private EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public PostpaidAccount save(PostpaidAccount postpaidAccount) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(postpaidAccount);
		entityManager.getTransaction().commit();
		entityManager.close();
		return postpaidAccount;
	}

	@Override
	public boolean update(PostpaidAccount postpaidAccount) {
		
		return false;
	}

	@Override
	public PostpaidAccount findOne(long mobileNo) {
		
		return null;
	}

	@Override
	public List<PostpaidAccount> findAll() {
		
		return null;
	}

	@Override
	public boolean closeCustomerPostpaidAccount(long mobileNo) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		PostpaidAccount postpaidAccount = findOne(mobileNo);
		entityManager.getTransaction().begin();
		entityManager.remove(mobileNo);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID) {
		return entityManagerFactory.createEntityManager().createQuery("from Customer c where c.customerID=" + customerID).getResultList();
	}

}
