package com.cg.billing.client;

import java.util.Scanner;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PlanDAOImpl;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

public class MainClass {
	static int count =0;
	static Scanner sc = new Scanner(System.in);
    static BillingServices services = new BillingServicesImpl();
    static BillingServicesImpl s = new BillingServicesImpl();
	public static void main(String[] args) 
	{
		 String option;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
        welcomeScreen();
        int choice = sc.nextInt();
        if(count==0) {
            s.createPlanDetails();
            count++;
    		}
        selectChoice(choice);
		/*
		 * do { System.out.println("Do you want to continue? " +
		 * "\n 1. Yes    \t \t      2. No" ); option = sc.next();
		 * }while(option.equalsIgnoreCase("Yes"));
		 */
	}
	public static void selectChoice(int choice)
	{
		switch(choice)
		{
		case 1: System.out.println(services.getPlanAllDetails());
		break;
		case 2: System.out.println("Enter firstName: ");
		String firstName = sc.next();
		System.out.println("Enter lastName: ");
		String lastName = sc.next();
		System.out.println("Enter emailId: ");
		String emailId = sc.next();
		System.out.println("Enter DOB: ");
		String dateOfBirth = sc.next();
		System.out.println("Enter billing address city: ");
		String billingAddressCity = sc.next();
		System.out.println("Enter billing address state: ");
		String billingAddressState = sc.next();
		System.out.println("Enter billing address pinCode: ");
		int billingAddressPinCode = sc.nextInt();
		System.out.println("Enter home address city: ");
		String homeAddressCity = sc.next();
		System.out.println("Enter home address state: ");
		String homeAddressState = sc.next();
		System.out.println("Enter home addess pinCode: ");
		int homeAddressPinCode = sc.nextInt();
		int customerID = services.acceptCustomerDetails(firstName, lastName, emailId, dateOfBirth, billingAddressCity, billingAddressState, billingAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
		System.out.println("Customer Id: " + customerID);
		break;
		case 3: System.out.println("Enter customerId: ");
		int customerId1 = sc.nextInt();
		System.out.println("Enter plan Id: ");
		int planId = sc.nextInt();
			try {
				System.out.println(services.openPostpaidMobileAccount(customerId1, planId));
			} catch (PlanDetailsNotFoundException e1) {
				e1.printStackTrace();
			} catch (CustomerDetailsNotFoundException e1) {
				e1.printStackTrace();
			}
		case 4: System.out.println("Enter customer Id: ");
		int customerId2 = sc.nextInt();
		System.out.println("Enter mobileNo: ");
		long mobileNo1 = sc.nextLong();
		System.out.println("Enter bill month: ");
		String billMonth = sc.next();
		System.out.println("Enter noOfLocalSMS: ");
		int noOfLocalSMS = sc.nextInt();
		System.out.println("Enter noOfStdSMS: ");
		int noOfStdSMS = sc.nextInt();
		System.out.println("Enter noOfLocalCalls: ");
		int noOfLocalCalls = sc.nextInt();
		System.out.println("Enter noOfStdCalls: ");
		int noOfStdCalls = sc.nextInt();
		System.out.println("Enter internetDataUsageUnits: ");
		int internetDataUsageUnits = sc.nextInt();
			try {
				System.out.println(services.generateMonthlyMobileBill(customerId2, mobileNo1, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			} catch (PostpaidAccountNotFoundException e) {
				e.printStackTrace();
			} catch (InvalidBillMonthException e) {
				e.printStackTrace();
			} catch (PlanDetailsNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 5: System.out.println("Enter customer Id: ");
		int customerId3 = sc.nextInt();
			try {
				System.out.println(services.getCustomerDetails(customerId3));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 6: System.out.println(services.getAllCustomerDetails());
		break;
		case 7: System.out.println("Enter customer Id: ");
		int customerId4 = sc.nextInt();
		System.out.println("Enter mobileNo: ");
		long mobileNo2 = sc.nextLong();
			try {
				System.out.println(services.getPostPaidAccountDetails(customerId4,mobileNo2));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			} catch (PostpaidAccountNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 8: System.out.println("Enter customer Id: ");
		int customerId5 = sc.nextInt();
			try {
				System.out.println(services.getCustomerAllPostpaidAccountsDetails(customerId5));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 9: System.out.println("Enter customer Id: ");
		int customerId6 = sc.nextInt();
		System.out.println("Enter mobileNo: ");
		long mobileNo3 = sc.nextLong();
		System.out.println("Enter bill month: ");
		String billMonth1 = sc.next();
			try {
				System.out.println(services.getMobileBillDetails(customerId6, mobileNo3,billMonth1));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			} catch (PostpaidAccountNotFoundException e) {
				e.printStackTrace();
			} catch (InvalidBillMonthException e) {
				e.printStackTrace();
			} catch (BillDetailsNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 10: System.out.println("Enter customer Id: ");
		int customerId7 = sc.nextInt();
		System.out.println("Enter mobileNo: ");
		long mobileNo4 = sc.nextLong();
			try {
				System.out.println(services.getCustomerPostPaidAccountAllBillDetails(customerId7, mobileNo4));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			} catch (PostpaidAccountNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 11: System.out.println("Enter customer Id: ");
		int customerId8 = sc.nextInt();
		System.out.println("Enter mobileNo: ");
		long mobileNo5 = sc.nextLong();
		System.out.println("Enter plan Id: ");
		int planId1 = sc.nextInt();
			try {
				System.out.println("Your Plan Has Been Changed! " + services.changePlan(customerId8, mobileNo5, planId1));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			} catch (PostpaidAccountNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 12: System.out.println("Enter customer Id: ");
		int customerId9 = sc.nextInt();
		System.out.println("Enter mobileNo: ");
		long mobileNo6 = sc.nextLong();
			try {
				System.out.println(services.closeCustomerPostPaidAccount(customerId9, mobileNo6));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			} catch (PostpaidAccountNotFoundException e) {
				e.printStackTrace();
			}
			break; 
		case 13: System.out.println("Enter customer Id: ");
		int customerId10 = sc.nextInt();
			try {
				System.out.println(services.removeCustomerDetails(customerId10));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			}
			break;
		case 14: System.out.println("Enter customer Id: ");
		int customerId11 = sc.nextInt();
		System.out.println("Enter mobileNo: ");
		long mobileNo7 = sc.nextLong();
			try {
				System.out.println(services.getCustomerPostPaidAccountPlanDetails(customerId11, mobileNo7));
			} catch (CustomerDetailsNotFoundException e) {
				e.printStackTrace();
			} catch (PostpaidAccountNotFoundException e) {
				e.printStackTrace();
			} catch (PlanDetailsNotFoundException e) {
				e.printStackTrace();
			}
			break;
			default: System.out.println("Invalid choice!");
		}
		System.out.println("What do you want to do now?");
    	System.out.println("1. Continue \n 2. Exit");
    	int select = sc.nextInt();
    	if(select == 2)
    		System.exit(0);
    	else
    		main(null);
		}
	
	
	public static void welcomeScreen()
	{
		System.out.println("***************************************MOBILE BILLING SYSTEM***********************************************");
		System.out.println("1. Get All Plan Details");
		System.out.println("2. Accept Customer Details");
		System.out.println("3. Open Postpaid Mobile Account");
		System.out.println("4. Generate Monthly Mobile Bill");
		System.out.println("5. Get Customer Details");
		System.out.println("6. Get All Customer Details");
		System.out.println("7. Get Postpaid Account Details");
		System.out.println("8. Get Customer All Postpaid Accounts Details");
		System.out.println("9. Get Mobile Bill Details");
		System.out.println("10. Get Customer PostPaid Account All Bill Details");
		System.out.println("11. Change Plan");
		System.out.println("12. Close Customer PostPaid Account");
		System.out.println("13. Remove Customer Details");
		System.out.println("14. Get Customer PostPaid Account Plan Details");
	
	}

}
